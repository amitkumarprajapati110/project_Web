// Declare a variable to store g1(x, y) function
let g1Function = '';

// Function to set values for a, b, c, d, κ, ν1(x, y), ν2(x, y), f(x, y), and g1(x, y)
function setValues() {
    var aValue = document.getElementById('a').value;
    var bValue = document.getElementById('b').value;
    var cValue = document.getElementById('c').value;
    var dValue = document.getElementById('d').value;
    var kappaValue = document.getElementById('kappa').value;
    var nu1Value = document.getElementById('nu1').value;
    var nu2Value = document.getElementById('nu2').value;
    var fValue = document.getElementById('functionF').value;
    var g1Value = document.getElementById('functionG1').value;
    var g2Value = document.getElementById('functionG2').value;
    var g3Value = document.getElementById('functionG3').value;
    var g4Value = document.getElementById('functionG4').value;
    var NValue = document.getElementById('degreeN').value;
    var NHValue = document.getElementById('NH').value;
    var NVValue = document.getElementById('NV').value;
     
    // Store values in variables a, b, c, d, κ, ν1(x, y), ν2(x, y), f(x, y), and g1(x, y)
    window.a = aValue;
    window.b = bValue;
    window.c = cValue;
    window.d = dValue;
    kappaFunction = kappaValue; // Store κ function string
    nu1Function = nu1Value; // Store ν1(x, y) function string
    nu2Function = nu2Value; // Store ν2(x, y) function string
    fFunction = fValue; // Store f(x, y) function string
    g1Function = g1Value; // Store g1(x, y) function string
    g2Function = g2Value;
    g3Function = g3Value;
    g4Function = g4Value;
    window.N = NValue;
    window.NH = NHValue;
    window.NV = NVValue;

}   
    
// Attach input event to setValues function for each input field
document.getElementById('a').addEventListener('input', setValues);
document.getElementById('b').addEventListener('input', setValues);
document.getElementById('c').addEventListener('input', setValues);
document.getElementById('d').addEventListener('input', setValues);
document.getElementById('kappa').addEventListener('input', setValues);
document.getElementById('nu1').addEventListener('input', setValues);
document.getElementById('nu2').addEventListener('input', setValues);
document.getElementById('functionF').addEventListener('input', setValues);
document.getElementById('functionG1').addEventListener('input', setValues);
document.getElementById('functionG2').addEventListener('input', setValues);
document.getElementById('functionG3').addEventListener('input', setValues);
document.getElementById('functionG4').addEventListener('input', setValues);
document.getElementById('degreeN').addEventListener('input', setValues);
document.getElementById('NH').addEventListener('input', setValues);
document.getElementById('NV').addEventListener('input', setValues);


// Declare a function to handle solving the equation
function solveEquation() {
    
    console.log('Equation solving logic goes here!');
}

// Get both radio buttons and the input field for g1
const drichleG1Radio = document.getElementById('drichleG1');
const numeralG1Radio = document.getElementById('numeralG1');
const functionG1Input = document.getElementById('functionG1');

// Add event listener to radio buttons for g1
drichleG1Radio.addEventListener('change', function() {
    if (this.checked) {
        functionG1Input.value = '';
    }
});

numeralG1Radio.addEventListener('change', function() {
    if (this.checked) {
        functionG1Input.value = '';
    }
});

// Function to get the value of g1 and its type
function getG1Value() {
    const g1Value = functionG1Input.value;
    const g1Type = drichleG1Radio.checked ? 'drichle' : 'numeral';
    
    return { value: g1Value, type: g1Type };
}

// Get both radio buttons and the input field for g2
const drichleG2Radio = document.getElementById('drichleG2');
const numeralG2Radio = document.getElementById('numeralG2');
const functionG2Input = document.getElementById('functionG2');

// Add event listener to radio buttons for g2
drichleG2Radio.addEventListener('change', function() {
    if (this.checked) {
        functionG2Input.value = '';
    }
});

numeralG2Radio.addEventListener('change', function() {
    if (this.checked) {
        functionG2Input.value = '';
    }
});

// Function to get the value of g2 and its type
function getG2Value() {
    const g2Value = functionG2Input.value;
    const g2Type = drichleG2Radio.checked ? 'drichle' : 'numeral';
    
    return { value: g2Value, type: g2Type };
}

// Get both radio buttons and the input field for g3
const drichleG3Radio = document.getElementById('drichleG3');
const numeralG3Radio = document.getElementById('numeralG3');
const functionG3Input = document.getElementById('functionG3');

// Add event listener to radio buttons for g3
drichleG3Radio.addEventListener('change', function() {
    if (this.checked) {
        functionG3Input.value = '';
    }
});

numeralG3Radio.addEventListener('change', function() {
    if (this.checked) {
        functionG3Input.value = '';
    }
});

// Function to get the value of g3 and its type
function getG3Value() {
    const g3Value = functionG3Input.value;
    const g3Type = drichleG3Radio.checked ? 'drichle' : 'numeral';
    
    return { value: g3Value, type: g3Type };
}

// Get both radio buttons and the input field for g4
const drichleG4Radio = document.getElementById('drichleG4');
const numeralG4Radio = document.getElementById('numeralG4');
const functionG4Input = document.getElementById('functionG4');

// Add event listener to radio buttons for g4
drichleG4Radio.addEventListener('change', function() {
    if (this.checked) {
        functionG4Input.value = '';
    }
});

numeralG4Radio.addEventListener('change', function() {
    if (this.checked) {
        functionG4Input.value = '';
    }
});

// Function to get the value of g4 and its type
function getG4Value() {
    const g4Value = functionG4Input.value;
    const g4Type = drichleG4Radio.checked ? 'drichle' : 'numeral';
    
    return { value: g4Value, type: g4Type };
}
